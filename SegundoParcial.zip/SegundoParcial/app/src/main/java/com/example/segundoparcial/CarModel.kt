package com.example.segundoparcial

data class CarModel(val brand: String, val model: String, val urlImage: String, val latitude: Double, val longitude: Double, val year: String)