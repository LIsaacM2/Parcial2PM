package com.example.segundoparcial

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.airbnb.lottie.LottieAnimationView

class MainActivity : AppCompatActivity() {
    internal lateinit var animationLottie: LottieAnimationView
    internal lateinit var userTxt: EditText
    internal lateinit var passwordTxt: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        animationLottie = findViewById(R.id.userAnim)
        animationLottie.setAnimation("user.json")
        animationLottie.playAnimation()
        animationLottie.loop(true)

        userTxt = findViewById(R.id.userTxt)
        passwordTxt = findViewById(R.id.passwordTxt)

        val logInBtn: Button = findViewById(R.id.logInBtn)
        logInBtn.setOnClickListener {
            if (userTxt.text.toString().equals("SegundoParcial") && passwordTxt.text.toString().equals("ULSA2021")) {
                val intent = Intent(this, WelcomePage::class.java).apply {
                }
                Toast.makeText(this, "Bienvenido.", Toast.LENGTH_SHORT).show()
                startActivity(intent)
                Log.d("Msj: ", "Bienvenido.")
            }else{
                Toast.makeText(this, "Contraseña o usuario incorrecto.", Toast.LENGTH_LONG).show()
            }
        }
    }
}