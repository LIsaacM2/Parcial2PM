package com.example.segundoparcial

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.budiyev.android.codescanner.AutoFocusMode
import com.budiyev.android.codescanner.CodeScanner
import com.budiyev.android.codescanner.CodeScannerView
import com.budiyev.android.codescanner.DecodeCallback
import com.budiyev.android.codescanner.ErrorCallback
import com.budiyev.android.codescanner.ScanMode

class QrReader : AppCompatActivity() {
    private lateinit var codeScanner: CodeScanner
    private val MY_CAMERA_PERMISSION_REQUEST = 1111
    private lateinit var scannerView: CodeScannerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_reader)

        scannerView = findViewById(R.id.scannerView)
        codeScanner = CodeScanner(this, scannerView)
        codeScanner.camera = CodeScanner.CAMERA_BACK
        codeScanner.formats = CodeScanner.ALL_FORMATS
        codeScanner.autoFocusMode = AutoFocusMode.SAFE
        codeScanner.scanMode = ScanMode.SINGLE
        codeScanner.isAutoFocusEnabled = true
        codeScanner.isFlashEnabled = false

        //Listener que detecta cuando se leyó un código QR
        codeScanner.decodeCallback = DecodeCallback {
            runOnUiThread {
                //Toast.makeText(this, "Scan result: ${it.text}", Toast.LENGTH_LONG).show()
                val intent = Intent(this, WelcomePage::class.java)
                //Pasar valores a la siguiente actividad
                var qrValues = it.text.split(",").toTypedArray()
                val brand = qrValues[0]
                val model = qrValues[1]
                val urlImage = qrValues[2]
                val latitude = qrValues[3]
                val longitude = qrValues[4]
                val year = qrValues[5]

                intent.putExtra("brand", brand)
                intent.putExtra("model", model)
                intent.putExtra("urlImage", urlImage)
                intent.putExtra("longitude", longitude)
                intent.putExtra("latitude", latitude)
                intent.putExtra("year", year)

                startActivity(intent)
                codeScanner.stopPreview()
            }
        }

        //Listener cuando hubo un error al leer algún código
        codeScanner.errorCallback = ErrorCallback {
            runOnUiThread {
                Toast.makeText(this, "Camera Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }

        //Inicializa la cámara
        codeScanner.startPreview()
        //Pedir permiso de uso de cámara
        checkPermission()
    }

    fun checkPermission(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), MY_CAMERA_PERMISSION_REQUEST)
        } else {
            codeScanner.startPreview()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode==MY_CAMERA_PERMISSION_REQUEST&&grantResults.isNotEmpty()&&grantResults[0]== PackageManager.PERMISSION_GRANTED){
            codeScanner.startPreview()
        } else {
            Toast.makeText(this, "Can not scan until you give the camera permission", Toast.LENGTH_LONG).show()
        }
    }


}