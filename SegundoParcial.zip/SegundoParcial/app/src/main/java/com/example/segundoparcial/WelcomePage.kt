package com.example.segundoparcial

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso

class WelcomePage : AppCompatActivity() {

    private var carBank = mutableListOf(
        CarModel("Tesla","Model X", "https://www.diariomotor.com/imagenes/picscache/1920x1600c/tesla-model-x-3_1920x1600c.jpg", 28.6489858, -106.1243254, "2021"),
        CarModel("BMW","i4", "https://soymotor.com/sites/default/files/styles/mega/public/imagenes/noticia/bmw_i4_2021.jpg?itok=Qb7n8sCJ", 28.6580881, -106.1994178, "2021"),
        CarModel("KIA","ev6", "https://i.blogs.es/05e2b9/kia-ev6_7/840_560.jpg", 28.6362035, -106.1409027, "2021")
    )

    private var currIndex = 0
    lateinit var carImg: ImageView
    lateinit var nextCar: Button
    lateinit var txtBrand: TextView
    lateinit var txtModel: TextView
    lateinit var txtYear: TextView
    lateinit var btnMap: Button
    lateinit var btnAddCar: Button
    lateinit var btnSignOut: Button
    internal lateinit var txtWelcome: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome_page)

        carImg=findViewById(R.id.imgCar)
        Picasso.get().setLoggingEnabled(true)
        Picasso.get().load(carBank[0].urlImage).centerCrop().resize(300,150).into(carImg)
        txtBrand = findViewById(R.id.txtBrand)
        nextCar = findViewById(R.id.btnNextCar)
        txtModel = findViewById(R.id.txtModel)
        txtYear = findViewById(R.id.txtYear)
        btnMap = findViewById(R.id.btnMap)
        btnAddCar = findViewById(R.id.btnAddCar)
        btnSignOut = findViewById(R.id.btnSignOut)
        txtWelcome = findViewById(R.id.welcomeTxt)

        val userName = intent.getStringExtra("userTxt")
        val brand = intent.getStringExtra("brand")
        val model = intent.getStringExtra("model")
        val urlImage = intent.getStringExtra("urlImage")
        val latitude = intent.getStringExtra("latitude")
        val longitude = intent.getStringExtra("longitude")
        val year = intent.getStringExtra("year")

        updateCar()

        if (userName != null){
            txtWelcome.text= userName.toString()
        }

        if (brand != null){
            carBank.add(CarModel(brand.toString(), model.toString(), urlImage.toString(),latitude.toString().toDouble(),longitude.toString().toDouble(),year.toString()))
        }

        nextCar.setOnClickListener {
            currIndex = (currIndex + 1) % carBank.size
            updateCar()
        }

        btnMap.setOnClickListener {
            val intent = Intent(this,Maps::class.java)
            intent.putExtra("latitude", carBank[currIndex].latitude)
            intent.putExtra("longitude",carBank[currIndex].longitude)
            startActivity(intent)
        }

        btnAddCar.setOnClickListener {
            val intent = Intent(this,QrReader::class.java).apply {

            }
            startActivity(intent)
        }

        btnSignOut.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java).apply {

            }
            startActivity(intent)
        }



    }
    private fun updateCar(){
        var image = carBank[currIndex].urlImage
        Picasso.get().load(image).centerCrop().resize(300,150).into(carImg)

        var brand = carBank[currIndex].brand
        txtBrand.setText(brand)

        var model = carBank[currIndex].model
        txtModel.setText(model)

        var year = carBank[currIndex].year
        txtYear.setText(year)
    }
}